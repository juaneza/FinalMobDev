package com.example.infinitysalon;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    TextInputEditText etUserName, etPassword;
    String username, password;
    LoadingDialog loadingDialog = new LoadingDialog();
    RequestQueue requestQueue;
    StringRequest stringRequest;
    Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        etUserName = findViewById(R.id.etUserName);
        etPassword = findViewById(R.id.etPassword);
        handler = new Handler();
    }

    public void register(View view) {
        startActivity(new Intent(this, RegisterActivity.class));
    }

    public void login(View view) {
        password = etPassword.getText().toString().toLowerCase().trim();
        username = etUserName.getText().toString().toLowerCase().trim();
        if (password.isEmpty() || username.isEmpty()) {
            Toast.makeText(this, "Enter your username and password", Toast.LENGTH_SHORT).show();
        } else {
            loadingDialog.startLoading(LoginActivity.this);
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (username.toLowerCase().trim().equals("admin") && password.toLowerCase().trim().equals("admin")) {
                        startActivity(new Intent(LoginActivity.this, AdminDashboardActivity.class));
                        loadingDialog.stopLoading();
                        finish();
                    } else {
                        login(username, password);
                    }
                }
            }, 2000);
        }
    }

    private void login(String username, String password) {
        stringRequest = new StringRequest(Request.Method.POST, "https://infinitysalonucu.000webhostapp.com/login.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (response.equals("ok")) {
                    loadingDialog.stopLoading();
                    finish();
                    startActivity(new Intent(LoginActivity.this, DashboardActivity.class).putExtra("username", username));
                } else {
                    Toast.makeText(LoginActivity.this, response, Toast.LENGTH_SHORT).show();
                    loadingDialog.stopLoading();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("password", password);
                return params;
            }
        };
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


}
package com.example.infinitysalon;

import android.app.Activity;
import android.app.Dialog;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import java.util.logging.Handler;

public class LoadingDialog {
    Dialog loading;
    Window window;
    public void startLoading(Activity activity){
        loading=new Dialog(activity);
        window=loading.getWindow();
        loading.setContentView(R.layout.layout_loading);
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        loading.setCancelable(false);
        loading.show();

    }
    public void stopLoading(){
        loading.dismiss();
    }
}

package com.example.infinitysalon;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    LoadingDialog loadingDialog = new LoadingDialog();
    StringRequest stringRequest;
    RequestQueue requestQueue;
    Bitmap bitmap;
    String encodedImage;
    ImageView ivUserImage;
    boolean uploaded=false;
    TextInputEditText etUserName, etPassword, etFirstName, etLastName, etEmail, etPhone;
    String username, password, firstname, lastname, email, phone;
    Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ivUserImage=findViewById(R.id.ivUserImage);
        etUserName = findViewById(R.id.etUserName);
        etPassword = findViewById(R.id.etPassword);
        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        handler=new Handler();
    }

    public void cancel(View view) {
        finish();
    }

    public void signup(View view) {
        username=etUserName.getText().toString().trim().toLowerCase();
        password=etPassword.getText().toString().trim().toLowerCase();
        firstname=etFirstName.getText().toString().trim().toLowerCase();
        lastname=etLastName.getText().toString().trim().toLowerCase();
        email=etEmail.getText().toString().trim().toLowerCase();
        phone=etPhone.getText().toString().trim().toLowerCase();
        if (username.isEmpty()||password.isEmpty()||firstname.isEmpty()||lastname.isEmpty()||email.isEmpty()||phone.isEmpty()){
            Toast.makeText(this, "Fill up all fields", Toast.LENGTH_SHORT).show();
        }else {
            if (uploaded){
                loadingDialog.startLoading(RegisterActivity.this);
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        register(username,password,firstname,lastname,email,phone);
                    }
                },2000);
            }else {
                Toast.makeText(this, "Pls upload photo", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void selectImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Browse Image"), 2);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2 && resultCode == RESULT_OK) {
            Uri filePath = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(filePath);
                bitmap = BitmapFactory.decodeStream(inputStream);
                ivUserImage.setImageBitmap(bitmap);
                imageStore(bitmap);
                uploaded = true;
            } catch (Exception e) {

            }
        }

    }

    private void imageStore(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, byteArrayOutputStream);

        byte[] imageBytes = byteArrayOutputStream.toByteArray();
        encodedImage = android.util.Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                selectImage();
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void register(String username, String password, String firstname, String lastname, String email, String phone) {
        stringRequest = new StringRequest(Request.Method.POST, "https://infinitysalonucu.000webhostapp.com/register.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (response.equals("ok")){
                    Toast.makeText(RegisterActivity.this, "Registered successfully!", Toast.LENGTH_SHORT).show();
                    loadingDialog.stopLoading();
                    finish();
                }else {
                    Toast.makeText(RegisterActivity.this, response, Toast.LENGTH_SHORT).show();
                    loadingDialog.stopLoading();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> params = new HashMap<>();
                params.put("username",username);
                params.put("password",password);
                params.put("firstname",firstname);
                params.put("lastname",lastname);
                params.put("email",email);
                params.put("phone",phone);
                params.put("pic",encodedImage);
                return params;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void upload(View view) {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        } else {
            selectImage();
        } }
}
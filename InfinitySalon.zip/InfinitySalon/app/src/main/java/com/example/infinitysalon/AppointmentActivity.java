package com.example.infinitysalon;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.infinitysalon.Adapter.AppointmentAdapter;
import com.example.infinitysalon.Class.Appointment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AppointmentActivity extends AppCompatActivity {
    private static ArrayList<Appointment> appointmentArrayList = new ArrayList<>();
    Intent intent;
    String date, time, services;
    String username;
    ArrayAdapter<String> servicesAdapter;
    ArrayAdapter<String> timeAdapter;
    Button ok, cancel;
    EditText etDate, etTime, etServices;
    Dialog addDialog;
    ListView lvAppointment;
    Appointment appointment;
    AppointmentAdapter appointmentAdapter;

    SimpleDateFormat sdf;
    Calendar myCalendar = Calendar.getInstance();
    String formattedDate;

    Handler handler;
    LoadingDialog loadingDialog = new LoadingDialog();

    StringRequest stringRequest;
    RequestQueue requestQueue;
    JSONObject object, jsonObject;
    JSONArray jsonArray;
    String gDate, gTime, gServies, gUsername,success,gFname,gLname,fullname,gId;

    TextView tvNoData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);
        tvNoData=findViewById(R.id.tvNoData);
        intent = getIntent();
        username = intent.getStringExtra("username");
        Date c = Calendar.getInstance().getTime();
        String myFormat = "yyyy-MM-dd"; //In which you need put here
        sdf = new SimpleDateFormat(myFormat, Locale.US);
        lvAppointment = findViewById(R.id.lvAppointment);
        appointmentAdapter = new AppointmentAdapter(this, appointmentArrayList);
        lvAppointment.setAdapter(appointmentAdapter);

        handler = new Handler();
        loadAppointments();

    }
    private void loadAppointments(){
        loadingDialog.startLoading(this);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                getAppointments(username);
            }
        }, 1000);
    }

    private void getAppointments(String username) {
        stringRequest = new StringRequest(Request.Method.POST, "https://infinitysalonucu.000webhostapp.com/getAppointment.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                appointmentArrayList.clear();
                try {
                    jsonObject=new JSONObject(response);
                    success=jsonObject.getString("success");
                    jsonArray=jsonObject.getJSONArray("appointment");
                    if (success.equals("1")){
                        for (int i=0;i<jsonArray.length();i++){
                            object=jsonArray.getJSONObject(i);

                            gServies=object.getString("services");
                            gTime=object.getString("time");
                            gDate=object.getString("date");
                            gFname=object.getString("firstname");
                            gLname=object.getString("lastname");
                            gId=object.getString("appointment_id");
                            fullname=gFname+" "+gLname;
                            appointment=new Appointment(gId,gServies,gTime,gDate,fullname);
                            appointmentArrayList.add(appointment);
                            appointmentAdapter.notifyDataSetChanged();
                        }
                        loadingDialog.stopLoading();
                        tvNoData.setVisibility(View.GONE);
                    }else {
                        loadingDialog.stopLoading();
                        tvNoData.setVisibility(View.VISIBLE);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("username", username);
                return params;
            }
        };
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public void back(View view) {
        appointmentArrayList.clear();
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        appointmentArrayList.clear();
    }

    public void addAppointment(View view) {
        addDialog = new Dialog(this);
        addDialog.setContentView(R.layout.layout_add_appointment);
        addDialog.setCancelable(false);
        Window window = addDialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        addDialog.show();
        ok = addDialog.findViewById(R.id.btnAdd);
        cancel = addDialog.findViewById(R.id.btnCancel);
        etDate = addDialog.findViewById(R.id.etDate);
        etTime = addDialog.findViewById(R.id.etTime);
        etServices = addDialog.findViewById(R.id.etService);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                date = etDate.getText().toString();
                time = etTime.getText().toString();
                services = etServices.getText().toString();
                if (time.isEmpty() || services.isEmpty() || date.isEmpty()) {
                    Toast.makeText(AppointmentActivity.this, "Pls complete all fields", Toast.LENGTH_SHORT).show();
                } else {
                    loadingDialog.startLoading(AppointmentActivity.this);
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            add(services, time, date);
                        }
                    }, 2000);
                }
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addDialog.dismiss();
            }
        });
        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDate();
            }
        });
        etTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showTime();
            }
        });
        etServices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showServices();
            }
        });
    }

    private void add(String services, String time, String date) {
        stringRequest = new StringRequest(Request.Method.POST, "https://infinitysalonucu.000webhostapp.com/addAppointment.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (response.equals("ok")) {
                    Toast.makeText(AppointmentActivity.this, "Added successfully!", Toast.LENGTH_SHORT).show();
                    loadingDialog.stopLoading();
                    addDialog.dismiss();
                    loadAppointments();
                } else {
                    Toast.makeText(AppointmentActivity.this, response, Toast.LENGTH_SHORT).show();
                    loadingDialog.stopLoading();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("services", services);
                params.put("date", date);
                params.put("time", time);
                return params;
            }
        };
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void showServices() {
        final String[] services_array = {"WAXING",
                "THREADING",
                "FACIAL",
                "MASSAGE",
                "EYEBROW/EYELASH TINTING",
                "MANICURE",
                "PEDICURE"};

        ListView listView = new ListView(this);
        servicesAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, services_array);
        listView.setAdapter(servicesAdapter);

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setCancelable(true);
        alert.setView(listView);
        final AlertDialog dialog = alert.create();

        etServices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.show();
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                etServices.setText(servicesAdapter.getItem(position));
                dialog.dismiss();
            }
        });
    }

    private void showTime() {
        final String[] time_array = {"8:00-09:00",
                "9:00-10:00",
                "11:00-12:00",
                "12:00-1:00",
                "1:00-2:00",
                "2:00-3:00",
                "3:00-4:00",
                "5:00-6:00"};

        ListView listView = new ListView(this);
        timeAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, time_array);
        listView.setAdapter(timeAdapter);

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setCancelable(true);
        alert.setView(listView);
        final AlertDialog dialog = alert.create();

        etTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.show();
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                etTime.setText(timeAdapter.getItem(position));
                dialog.dismiss();
            }
        });
    }

    private void showDate() {
        DatePickerDialog.OnDateSetListener first_date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                etDate.setText(sdf.format(myCalendar.getTime()));
            }
        };
        new DatePickerDialog(AppointmentActivity.this, first_date, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show();
    }
}
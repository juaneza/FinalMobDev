package com.example.infinitysalon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class DashboardActivity extends AppCompatActivity {
    Intent intent;
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        intent=getIntent();
        username=intent.getStringExtra("username");
    }

    public void about(View view) {
        startActivity(new Intent(this,AboutActivity.class));
    }

    public void appointment(View view) {
        startActivity(new Intent(this,AppointmentActivity.class).putExtra("username",username));
    }
    public void services(View view){
        startActivity(new Intent(this,ServicesActivity.class));
    }
}
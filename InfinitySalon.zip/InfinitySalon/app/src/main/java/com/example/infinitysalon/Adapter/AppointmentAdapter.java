package com.example.infinitysalon.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.infinitysalon.Class.Appointment;
import com.example.infinitysalon.R;

import java.util.ArrayList;

public class AppointmentAdapter extends ArrayAdapter<Appointment> {
    private static ArrayList<Appointment> appointmentArrayList;
    Context context;
    public AppointmentAdapter(@NonNull Context context, ArrayList<Appointment> appointmentArrayList) {
        super(context, R.layout.layout_appointment,appointmentArrayList);
        this.context=context;
        this.appointmentArrayList=appointmentArrayList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_appointment,null,false);

        TextView tvDate = view.findViewById(R.id.tvDate);
        TextView tvTime = view.findViewById(R.id.tvTime);
        TextView tvService = view.findViewById(R.id.tvService);
        TextView tvName = view.findViewById(R.id.tvName);
        TextView tvId = view.findViewById(R.id.tvAppointmentId);

        Appointment appointment = appointmentArrayList.get(position);
        tvDate.setText(appointment.getDate());
        tvTime.setText(appointment.getTime());
        tvService.setText(appointment.getService());
        tvName.setText(appointment.getName());
        tvId.setText(appointment.getAppointment_id());
        return view;
    }
}

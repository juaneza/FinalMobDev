package com.example.infinitysalon.Class;

import com.example.infinitysalon.Adapter.AppointmentAdapter;

public class Appointment {
    String appointment_id,date,time,service,name;

    public Appointment(String appointment_id, String date, String time, String service, String name) {
        this.appointment_id = appointment_id;
        this.date = date;
        this.time = time;
        this.service = service;
        this.name = name;
    }

    public String getAppointment_id() {
        return appointment_id;
    }

    public void setAppointment_id(String appointment_id) {
        this.appointment_id = appointment_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

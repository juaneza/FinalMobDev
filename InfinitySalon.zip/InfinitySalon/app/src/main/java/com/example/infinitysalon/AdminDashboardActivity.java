package com.example.infinitysalon;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.infinitysalon.Adapter.AppointmentAdapter;
import com.example.infinitysalon.Class.Appointment;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AdminDashboardActivity extends AppCompatActivity {
    TextView tvNoData;
    Dialog completeDialog;
    Button btnComplete;
    private static ArrayList<Appointment> appointmentArrayList = new ArrayList<>();
    String username;
    ListView lvAppointment;
    Appointment appointment;
    AppointmentAdapter appointmentAdapter;
    Handler handler;
    LoadingDialog loadingDialog = new LoadingDialog();

    StringRequest stringRequest;
    RequestQueue requestQueue;
    JSONObject object, jsonObject;
    JSONArray jsonArray;
    String gDate, gTime, gServies, success, gFname, gLname, fullname, gId;

    TextInputEditText etServices,etName,etDate,etTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);
        tvNoData=findViewById(R.id.tvNoData);
        lvAppointment = findViewById(R.id.lvAppointment);
        appointmentAdapter = new AppointmentAdapter(this, appointmentArrayList);
        lvAppointment.setAdapter(appointmentAdapter);

        lvAppointment.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView id = view.findViewById(R.id.tvAppointmentId);
                TextView services = view.findViewById(R.id.tvService);
                TextView name = view.findViewById(R.id.tvName);
                TextView time = view.findViewById(R.id.tvTime);
                TextView date = view.findViewById(R.id.tvDate);

                String getId,getServices,getName,getTime,getDate;
                getId=id.getText().toString();
                getServices=services.getText().toString();
                getName=name.getText().toString();
                getTime=time.getText().toString();
                getDate=date.getText().toString();

                completeDialog(getId,getServices,getName,getTime,getDate);
            }
        });

        handler = new Handler();
        loadAppointments();
    }

    private void completeDialog(String getId, String getServices, String getName, String getTime, String getDate) {
        completeDialog=new Dialog(this);
        completeDialog.setContentView(R.layout.layout_finish);
        Window window = completeDialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        completeDialog.show();

        etServices=completeDialog.findViewById(R.id.etService);
        etTime=completeDialog.findViewById(R.id.etTime);
        etDate=completeDialog.findViewById(R.id.etDate);
        etName=completeDialog.findViewById(R.id.etName);

        etTime.setText(getTime);
        etServices.setText(getServices);
        etDate.setText(getDate);
        etName.setText(getName);

        btnComplete=completeDialog.findViewById(R.id.btnComplete);
        btnComplete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadingDialog.startLoading(AdminDashboardActivity.this);
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        completeAppointment(getId);
                    }
                },1000);
            }
        });
    }

    private void completeAppointment(String getId) {
        stringRequest=new StringRequest(Request.Method.POST, "https://infinitysalonucu.000webhostapp.com/delAppointment.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (response.equals("ok")){
                    completeDialog.dismiss();
                    loadingDialog.stopLoading();
                    loadAppointments();
                    Toast.makeText(AdminDashboardActivity.this, "Appointment Completed!", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(AdminDashboardActivity.this, response, Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> params = new HashMap<>();
                params.put("appointment_id",getId);
                return params;
            }
        };
        requestQueue=Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void loadAppointments() {
        loadingDialog.startLoading(this);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                getAppointments(username);
            }
        }, 1000);
    }

    private void getAppointments(String username) {
        stringRequest = new StringRequest(Request.Method.POST, "https://infinitysalonucu.000webhostapp.com/getAllAppointments.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                appointmentArrayList.clear();
                try {
                    jsonObject = new JSONObject(response);
                    success = jsonObject.getString("success");
                    jsonArray = jsonObject.getJSONArray("appointment");
                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            object = jsonArray.getJSONObject(i);

                            gServies = object.getString("services");
                            gTime = object.getString("time");
                            gDate = object.getString("date");
                            gFname = object.getString("firstname");
                            gLname = object.getString("lastname");
                            gId = object.getString("appointment_id");
                            fullname = gFname + " " + gLname;
                            appointment = new Appointment(gId, gServies, gTime, gDate, fullname);
                            appointmentArrayList.add(appointment);
                            appointmentAdapter.notifyDataSetChanged();
                        }
                        loadingDialog.stopLoading();
                        tvNoData.setVisibility(View.GONE);
                    }else {
                        loadingDialog.stopLoading();
                        tvNoData.setVisibility(View.VISIBLE);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public void back(View view) {
        appointmentArrayList.clear();
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        appointmentArrayList.clear();
    }

}